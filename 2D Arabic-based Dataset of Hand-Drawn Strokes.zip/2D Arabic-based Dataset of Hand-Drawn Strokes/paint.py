from tkinter import *
from tkinter import colorchooser, filedialog, messagebox
from tkinter import Toplevel, Label
import PIL.ImageGrab as ImageGrab
from PIL import Image, ImageTk
from pynput import *
import pandas as pd
import csv
import os
import atexit
import time
from datetime import datetime
from ultralytics import YOLO
import numpy as np

# Load the pre-trained YOLO model
model = YOLO('C:\\Users\\DELL\\Desktop\\2D Arabic-based Dataset of Hand-Drawn Strokes\\runs\\classify\\train4\\weights\\last.pt')

# Initialize the main application window
root = Tk()
root.title("Paint App")
root.geometry("800x600")

# ----------------- Variables ----------------

options = [1, 2, 3, 4, 5, 10]

stroke_size = IntVar()
stroke_size.set(1)

stroke_color = StringVar()
stroke_color.set("black")

previousColor = StringVar()
previousColor.set("yellow")

previousColor2 = StringVar()
previousColor2.set("red")

drawn_objects = []
prediction_text_id = None  # Track the prediction text to update it

# ---------------- Functions ------------------

def usePencil():
    stroke_color.set("black")
    canvas["cursor"] = "arrow"

def useEraser():
    stroke_color.set("white")
    canvas["cursor"] = "dotbox"

def selectColor():
    selectedColor = colorchooser.askcolor("blue", title="Select Color")
    if selectedColor[1] is None:
        stroke_color.set("black")
    else:
        stroke_color.set(selectedColor[1])
        previousColor2.set(previousColor.get())
        previousColor.set(selectedColor[1])

        previousColorButton["bg"] = previousColor.get()
        previousColor2Button["bg"] = previousColor2.get()

coordinates = []

def paint(event):
    global coordinates

    x = event.x
    y = event.y
    current_point = [x, y]

    coordinates.append(current_point)

    if len(coordinates) > 1:
        prev_x, prev_y = coordinates[-2]
        curr_x, curr_y = coordinates[-1]
        canvas.create_line(prev_x, prev_y, curr_x, curr_y,
                           fill=stroke_color.get(), width=stroke_size.get())

    if event.type == "5":  # ButtonRelease event
        print("Stroke Coordinates:")
        for point in coordinates:
            print(f"X: {point[0]}, Y: {point[1]}")

        draw_lines(coordinates)

        with open("stroke_data.csv", "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([f"{point[0]},{point[1]}" for point in coordinates])

        coordinates = []

       
        capture_and_predict()

def draw_lines(coords):
    global drawn_objects
    stroke = []

    for i in range(1, len(coords)):
        prev_x, prev_y = coords[i-1]
        curr_x, curr_y = coords[i]
        line_id = canvas.create_line(prev_x, prev_y, curr_x, curr_y,
                                     fill=stroke_color.get(), width=stroke_size.get())
        stroke.append((prev_x, prev_y, curr_x, curr_y))
    drawn_objects.append(stroke)

# Global variables
prediction_text_id = None  
all_predictions = []  
def capture_and_predict():
    

    global prediction_text_id

    canvas_x = canvas.winfo_rootx()
    canvas_y = canvas.winfo_rooty()
    canvas_width = canvas.winfo_width()
    canvas_height = canvas.winfo_height()

    bbox = (canvas_x, canvas_y, canvas_x + canvas_width, canvas_y + canvas_height)
    img = ImageGrab.grab(bbox=bbox)
    img.save("captured_canvas.png")

    def preprocess_image(img):
        desired_size = (64, 64)
        img = img.resize(desired_size)
        img_array = np.array(img) / 255.0
        return (img_array * 255).astype(np.uint8)

    img_array = preprocess_image(img)
    img_for_prediction = Image.fromarray(img_array)

    # Perform prediction
    results = model.predict(img_for_prediction)
    predictions = [(results[0].names[i], prob) for i, prob in enumerate(results[0].probs.data.tolist()) if prob > 0]

    # Sort predictions by probability in descending order and select the top 5
    top_predictions = sorted(predictions, key=lambda x: x[1], reverse=True)[:5]
    
    # Format the prediction text to display the top 5 predictions
    prediction_str = "Top Predictions:\n" + "\n".join([f"{name}: {prob:.2%}" for name, prob in top_predictions])

    

    if prediction_text_id is not None:
        canvas.delete(prediction_text_id)

    # Draw the updated prediction at the bottom-right of the canvas
    prediction_text_id = canvas.create_text(
        canvas_width - 10, canvas_height - 10,
        anchor='se',  # Southeast corner
        text=prediction_str,
        fill='black',
        font=('Arial', 16)
    )



def saveImage():
    try:
        fileLocation = filedialog.asksaveasfilename(defaultextension=".jpg")
        x = root.winfo_rootx()
        y = root.winfo_rooty() + 150
        img = ImageGrab.grab(bbox=(x, y, x + 800, y + 400))
        img.save(fileLocation)

        global_start_time = time.time()

        csv_file_name = os.path.splitext(fileLocation)[0] + ".csv"
        with open(csv_file_name, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["x coordinate", "y coordinate", "stroke number", "start time", "end time", "duration"])

            for stroke_number, coordinates_set in enumerate(drawn_objects, start=1):
                start_time = global_start_time + coordinates_set[0][2]
                end_time = global_start_time + coordinates_set[-1][2]
                duration = abs(end_time - start_time)

                for point in coordinates_set:
                    writer.writerow([point[0], point[1], stroke_number, start_time, end_time, duration])

        open("stroke_data.csv", "w").close()

        showImage = messagebox.askyesno("Paint App", "Do you want to open image?")
        if showImage:
            img.show()

    except Exception as e:
        messagebox.showinfo("Paint app:", f"Error occurred: {e}")

def clear():
    if messagebox.askokcancel("Paint app", "Do you want to clear everything?"):
        canvas.delete('all')
        with open("stroke_data.csv", "w") as file:
            file.truncate(0)
        coordinates.clear()

def createNew():
    if messagebox.askyesno("Paint app", "Do you want to save before you clear everything?"):
        saveImage()
    clear()

textValue = StringVar()

def writeText(event):
    canvas.create_text(event.x, event.y, text=textValue.get())

def undo():
    global drawn_objects

    if drawn_objects:
        
        last_stroke = drawn_objects.pop()

        for line_coords in last_stroke:
           
            line_ids = [
                line_id for line_id in canvas.find_all()
                if tuple(canvas.coords(line_id)) == line_coords
            ]

            
            for line_id in line_ids:
                canvas.delete(line_id)

        
        with open("stroke_data.csv", "r") as file:
            lines = file.readlines()
        with open("stroke_data.csv", "w") as file:
            file.writelines(lines[:-1])


def showimage():
    fln = filedialog.askopenfilename(
        initialdir=os.getcwd(),
        title='Select image file',
        filetypes=(('PNG file', '*.png'), ('All files', '*.*'))
    )
    if fln:
        try:
            img = Image.open(fln)
            img.thumbnail((350, 350))
            img = ImageTk.PhotoImage(img)

            top = Toplevel(root)
            top.title("Image")
            lbl = Label(top, image=img)
            lbl.pack()
            top.mainloop()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open image: {e}")

def clear_stroke_data():
    open("stroke_data.csv", "w").close()

atexit.register(clear_stroke_data)

# ------------------- User Interface -------------------

lbl = Label(root)
lbl.pack()

# Frame - 1: Tools
frame1 = Frame(root)
frame1.pack(side=TOP, fill=BOTH, expand=True)

# Tools Frame
toolsFrame = Frame(frame1, height=100, width=100, relief=SUNKEN, borderwidth=3)
toolsFrame.pack(side=LEFT)

pencilButton = Button(toolsFrame, text="Pencil", width=10, command=usePencil)
pencilButton.pack(side=TOP)
eraserButton = Button(toolsFrame, text="Eraser", width=10, command=useEraser)
eraserButton.pack(side=TOP)
toolsLabel = Label(toolsFrame, text="Tools", width=10)
toolsLabel.pack(side=TOP)

# Size Frame
sizeFrame = Frame(frame1, height=100, width=100, relief=SUNKEN, borderwidth=3)
sizeFrame.pack(side=LEFT)

defaultButton = Button(sizeFrame, text="Default", width=10, command=usePencil)
defaultButton.pack(side=TOP)
sizeList = OptionMenu(sizeFrame, stroke_size, *options)
sizeList.pack(side=TOP)
sizeLabel = Label(sizeFrame, text="Size", width=10)
sizeLabel.pack(side=TOP)

# Color Box Frame
colorBoxFrame = Frame(frame1, height=100, width=100, relief=SUNKEN, borderwidth=3)
colorBoxFrame.pack(side=LEFT)

colorBoxButton = Button(colorBoxFrame, text="Select Color", width=10, command=selectColor)
colorBoxButton.pack(side=TOP)
previousColorButton = Button(colorBoxFrame, text="Previous", width=10, command=lambda: stroke_color.set(previousColor.get()))
previousColorButton.pack(side=TOP)
previousColor2Button = Button(colorBoxFrame, text="Previous2", width=10, command=lambda: stroke_color.set(previousColor2.get()))
previousColor2Button.pack(side=TOP)

# Colors Frame
colorsFrame = Frame(frame1, height=100, width=100, relief=SUNKEN, borderwidth=3)
colorsFrame.pack(side=LEFT)

redButton = Button(colorsFrame, text="Red", bg="red", width=10, command=lambda: stroke_color.set("red"))
redButton.grid(row=0, column=0, pady=5)
greenButton = Button(colorsFrame, text="Green", bg="green", width=10, command=lambda: stroke_color.set("green"))
greenButton.grid(row=0, column=1, pady=5)
blueButton = Button(colorsFrame, text="Blue", bg="blue", width=10, command=lambda: stroke_color.set("blue"))
blueButton.grid(row=1, column=0, pady=5)
yellowButton = Button(colorsFrame, text="Yellow", bg="yellow", width=10, command=lambda: stroke_color.set("yellow"))
yellowButton.grid(row=1, column=1, pady=5)
orangeButton = Button(colorsFrame, text="Orange", bg="orange", width=10, command=lambda: stroke_color.set("orange"))
orangeButton.grid(row=2, column=0, pady=5)
purpleButton = Button(colorsFrame, text="Purple", bg="purple", width=10, command=lambda: stroke_color.set("purple"))
purpleButton.grid(row=2, column=1, pady=5)

# Save Image Frame
saveImageFrame = Frame(frame1, height=100, width=100, relief=SUNKEN, borderwidth=3)
saveImageFrame.pack(side=LEFT)

saveImageButton = Button(saveImageFrame, text="Save", bg="white", width=10, command=saveImage)
saveImageButton.pack(side=TOP)
newImageButton = Button(saveImageFrame, text="New", bg="white", width=10, command=createNew)
newImageButton.pack(side=TOP)
clearImageButton = Button(saveImageFrame, text="Clear", bg="white", width=10, command=clear)
clearImageButton.pack(side=TOP)

# Undo Frame
undoFrame = Frame(frame1, height=100, width=100, relief=SUNKEN, borderwidth=3)
undoFrame.pack(side=LEFT)

undoButton = Button(undoFrame, text="Undo", bg="white", width=10, command=undo)
undoButton.pack(side=TOP)

guideButton = Button(undoFrame, text="Guide", bg="white", width=10, command=showimage)
guideButton.pack(side=TOP)

# Frame - 2 - Canvas
frame2 = Frame(root, height=500, width=1100, bg="yellow")
frame2.pack()

# Canvas
canvas = Canvas(frame2, height=500, width=1100, bg="white")
canvas.pack()

# Bind the painting function to the canvas
canvas.bind("<B1-Motion>", paint)
canvas.bind("<ButtonRelease-1>", paint)
canvas.bind("<Button-2>", writeText)

root.resizable(False, False)
root.mainloop()

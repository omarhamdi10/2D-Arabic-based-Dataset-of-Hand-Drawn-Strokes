import tkinter as tk
from tkinter import filedialog, messagebox  
import csv
import matplotlib.pyplot as plt

def read_coordinates(file_path):
    try:
        with open(file_path, 'r') as file:
            reader = csv.reader(file)
            next(reader)  
            coordinates = []  
            stroke = []  
            prev_stroke_number = None  
            for row in reader:
                if len(row) >= 3:
                    x, y, stroke_number = map(int, row[:3])
                    if stroke_number != prev_stroke_number:
                        if stroke:
                            coordinates.append(stroke)
                            stroke = []
                    stroke.append((x, y))
                    prev_stroke_number = stroke_number
            if stroke:
                coordinates.append(stroke)
            return coordinates
    except Exception as e:
        messagebox.showerror("Error", f"Failed to read the file: {e}")
        return []

def plot_strokes(canvas, strokes, delay=3000):
    if not strokes:
        return
    for stroke in strokes:
        for i in range(len(stroke) - 1):
            x1, y1 = stroke[i]
            x2, y2 = stroke[i + 1]
            canvas.create_line(x1, y1, x2, y2)
        canvas.update()
        canvas.after(delay)  

def start_plotting():
    file_path = filedialog.askopenfilename(title="Select a CSV file",
                                           filetypes=(("CSV files", "*.csv"), ("All files", "*.*")))
    if file_path:
        entry.delete(0, tk.END)
        entry.insert(0, file_path)
        canvas.delete("all")
        strokes = read_coordinates(file_path)
        plot_strokes(canvas, strokes)



# Create tkinter window
root = tk.Tk()
root.title("Plot Strokes from CSV")

entry = tk.Entry(root, width=50)
entry.pack(pady=10)

start_button = tk.Button(root, text="Start Plotting", command=start_plotting)
start_button.pack(pady=5)



canvas = tk.Canvas(root, width=800, height=500)
canvas.pack()

root.mainloop()

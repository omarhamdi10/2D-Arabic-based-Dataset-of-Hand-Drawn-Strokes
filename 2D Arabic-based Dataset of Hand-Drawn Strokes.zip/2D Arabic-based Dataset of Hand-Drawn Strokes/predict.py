from ultralytics import YOLO
import numpy as np

# Load the trained model
model = YOLO('C:\\Users\\DELL\\Desktop\\2D Arabic-based Dataset of Hand-Drawn Strokes\\runs\\classify\\train4\\weights\\last.pt')

def predict_single_image(image_path):
    results = model(image_path)
    names_dict = results[0].names
    probs = results[0].probs.data.tolist()
    
    print("Class Labels:", names_dict)
    print("Probabilities:", probs)
    
    # Print the most probable class
    print("Predicted Class:", names_dict[np.argmax(probs)])

def evaluate_model_on_test_set(test_data_path):
    metrics = model.val(data=test_data_path, imgsz=64)
    print("Model Evaluation Metrics:", metrics)


# Prediction on a single image
#predict_single_image('C:\\Users\\DELL\\Desktop\\predict\\12.jpg')

# Evaluation on a test dataset
evaluate_model_on_test_set('C:\\Users\\DELL\\Desktop\\IMAGESONLY')

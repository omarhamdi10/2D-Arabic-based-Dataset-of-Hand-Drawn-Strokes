from ultralytics import YOLO

model = YOLO('yolov8n-cls.pt')  
model.train(data='C:\\Users\\DELL\\Desktop\\IMAGESONLY', epochs=20, imgsz=64)